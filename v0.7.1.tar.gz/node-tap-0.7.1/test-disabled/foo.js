process.stdin
