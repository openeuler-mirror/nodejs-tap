#!/bin/sh

echo "1..1"
echo "ok 1 File with executable bit should be executed"
