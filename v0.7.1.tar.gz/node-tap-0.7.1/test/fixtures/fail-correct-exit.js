console.log('TAP Version 13')
console.log('not ok - 1 and it will exit non-zero')
console.log('1..1')
process.exit(1)
