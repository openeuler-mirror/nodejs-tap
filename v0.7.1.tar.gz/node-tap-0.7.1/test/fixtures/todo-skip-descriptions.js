console.log('ok - always passes # SKIP skip it, skip it good')
console.log('not ok - false # SKIP always fails')
console.log('ok - bonus # TODO remove todo directive')
console.log('not ok - expected # TODO implement a thing')
