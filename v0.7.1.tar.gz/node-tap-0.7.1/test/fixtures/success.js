console.log('TAP Version 13')
console.log('ok - 1 and exit 0')
console.log('1..1')
