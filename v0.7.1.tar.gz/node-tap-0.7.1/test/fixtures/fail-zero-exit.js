console.log('TAP Version 13')
console.log('not ok - 1 but it will exit zero')
console.log('1..1')
process.exit(0)
