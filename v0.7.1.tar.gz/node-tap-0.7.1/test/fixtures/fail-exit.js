console.log('TAP Version 13')
console.log('ok - 1 but it will exit non-zero')
console.log('1..1')
process.exit(1)
