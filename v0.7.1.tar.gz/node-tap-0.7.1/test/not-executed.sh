#!/bin/sh

echo "1..1"
echo "not ok 1 File without executable bit should not be run"
exit 1
